# LA ESTACADA Finanzas — base compartida

## Puesta en marcha
1. Crear un proyecto en https://supabase.com/ .
2. Abrir SQL Editor y ejecutar `schema.sql` (en proyecto nuevo).
3. En Authentication > Providers > Email, desactivar **Allow new users to sign up** (registro público). Crear/invitar exactamente tres usuarios desde Authentication > Users. Para invitaciones, configurar el URL del sitio en Authentication > URL Configuration.
4. Copiar los UUID de los usuarios y ejecutar el INSERT de perfiles al final de `schema.sql`, sustituyendo los UUID reales. Solo Bautista tiene `admin`.
5. En Project Settings / API copiar **Project URL** y la clave pública **publishable/anon** al archivo `config.js`. NUNCA usar `service_role` ni `secret` en el navegador.
6. Subir `index.html`, `config.js`, `manifest.webmanifest` a un hosting HTTPS estático (por ejemplo Netlify o Cloudflare Pages). Configurar la URL de publicación en Authentication > URL Configuration. Abrir la URL e ingresar con los usuarios invitados.
7. Desde la cuenta de administrador, crear cuentas ARS/USD y cargar saldos iniciales. Cargar movimientos nuevos para aprobación.

## Reglas de contabilidad
- Solo movimientos aprobados afectan el saldo. El saldo = saldos iniciales por moneda + ingresos aprobados − egresos aprobados.
- Deudas no afectan el saldo hasta que se registre su pago como movimiento independiente.
- Las inversiones se registran como egresos de categoría inversión, sin valorización automática.
- Presupuesto muestra gastos mensuales aprobados del mes, no proyecciones ni conciliación de pagos.
- Los saldos no se convierten automáticamente entre monedas.
- La sección personal solo existe para el administrador; RLS limita además las filas al propio usuario.

## Antes de producción financiera
Esto es una **base funcional inicial**, no un sistema contable auditado. Falta conciliación bancaria, soporte de comprobantes, auditoría inmutable detallada, recuperación/backup, MFA, edición con correcciones reversibles, y notificaciones. Configurar backups, MFA y políticas de seguridad antes de usar dinero real. No importar datos históricos sin revisar saldos iniciales para evitar doble contabilización.

## Instalar como app (PWA)
Esta versión incorpora el logo original invertido, iconos y manifest PWA. Publicar toda la carpeta en HTTPS; no abrir el HTML como archivo local para instalar. iPhone: Safari > Compartir > Añadir a pantalla de inicio. Mac: Safari > Archivo > Añadir al Dock (versiones compatibles). La instalación no configura Supabase ni publica la web automáticamente.
