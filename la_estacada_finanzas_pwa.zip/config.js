// Configuración pública de Supabase. NUNCA colocar la service_role key aquí.
window.ESTACADA_CONFIG = {url:'REEMPLAZAR_CON_SUPABASE_URL', anonKey:'REEMPLAZAR_CON_SUPABASE_PUBLISHABLE_KEY'};
