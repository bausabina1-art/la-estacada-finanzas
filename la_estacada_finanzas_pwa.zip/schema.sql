-- Ejecutar en Supabase SQL Editor en un proyecto NUEVO.
create extension if not exists pgcrypto;
create table public.profiles (id uuid primary key references auth.users(id) on delete cascade, display_name text not null default '', role text not null default 'member' check (role in ('admin','member')), created_at timestamptz not null default now());
create table public.accounts (id uuid primary key default gen_random_uuid(), name text not null, currency text not null check(currency in ('ARS','USD')), opening_balance numeric(18,2) not null default 0, created_at timestamptz not null default now());
create table public.movements (id uuid primary key default gen_random_uuid(), account_id uuid references public.accounts(id), title text not null, amount numeric(18,2) not null check(amount>0), currency text not null check(currency in ('ARS','USD')), direction text not null check(direction in ('income','expense')), category text not null check(category in ('monthly','variable','investment','other')), status text not null default 'pending' check(status in ('pending','approved','rejected')), occurred_on date not null default current_date, created_by uuid not null default auth.uid() references auth.users(id), reviewed_by uuid references auth.users(id), reviewed_at timestamptz, created_at timestamptz not null default now());
create table public.obligations (id uuid primary key default gen_random_uuid(), title text not null, amount numeric(18,2) not null check(amount>0), currency text not null check(currency in ('ARS','USD')), kind text not null check(kind in ('payable','receivable')), due_on date, status text not null default 'pending' check(status in ('pending','approved','rejected')), settled boolean not null default false, created_by uuid not null default auth.uid() references auth.users(id), reviewed_by uuid references auth.users(id), created_at timestamptz not null default now());
create table public.budgets (id uuid primary key default gen_random_uuid(), month date not null, currency text not null check(currency in ('ARS','USD')), amount numeric(18,2) not null check(amount>=0), unique(month,currency));
create table public.personal_movements (id uuid primary key default gen_random_uuid(), owner_id uuid not null default auth.uid() references auth.users(id), title text not null, amount numeric(18,2) not null check(amount>0), currency text not null check(currency in ('ARS','USD')), direction text not null check(direction in ('income','expense')), occurred_on date not null default current_date, created_at timestamptz not null default now());
create function public.is_admin() returns boolean language sql stable security definer set search_path='' as $$ select exists(select 1 from public.profiles where id=(select auth.uid()) and role='admin') $$;
revoke all on function public.is_admin() from public; grant execute on function public.is_admin() to authenticated;
-- Trigger protege estados y autores incluso ante llamadas directas a API.
create function public.guard_movement() returns trigger language plpgsql security invoker as $$ begin
if new.account_id is not null and not exists(select 1 from public.accounts a where a.id=new.account_id and a.currency=new.currency) then raise exception 'La moneda no coincide con la cuenta'; end if;
if tg_op='INSERT' then new.created_by:=auth.uid(); new.status:='pending'; new.reviewed_by:=null; new.reviewed_at:=null;
elsif tg_op='UPDATE' then
 if not public.is_admin() then raise exception 'Solo el administrador puede modificar movimientos'; end if;
 if old.status <> 'pending' and (new.status is distinct from old.status or new.amount is distinct from old.amount or new.account_id is distinct from old.account_id or new.direction is distinct from old.direction) then raise exception 'No se pueden modificar operaciones ya resueltas'; end if;
 new.created_by:=old.created_by;
 if new.status <> old.status then new.reviewed_by:=auth.uid(); new.reviewed_at:=now(); end if;
end if; return new; end $$;
create trigger movement_guard before insert or update on public.movements for each row execute function public.guard_movement();
create function public.guard_obligation() returns trigger language plpgsql security invoker as $$ begin
if tg_op='INSERT' then new.created_by:=auth.uid(); new.status:='pending'; new.reviewed_by:=null;
elsif tg_op='UPDATE' then
 if not public.is_admin() then raise exception 'Solo administrador'; end if;
 if old.status <> 'pending' and new.status is distinct from old.status then raise exception 'Estado definitivo'; end if;
 new.created_by:=old.created_by; if new.status <> old.status then new.reviewed_by:=auth.uid(); end if;
end if; return new; end $$;
create trigger obligation_guard before insert or update on public.obligations for each row execute function public.guard_obligation();
alter table public.profiles enable row level security;
alter table public.accounts enable row level security;
alter table public.movements enable row level security;
alter table public.obligations enable row level security;
alter table public.budgets enable row level security;
alter table public.personal_movements enable row level security;
create policy profiles_read on public.profiles for select to authenticated using (true);
create policy accounts_read on public.accounts for select to authenticated using (true);
create policy accounts_admin on public.accounts for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy movements_read on public.movements for select to authenticated using (true);
create policy movements_add on public.movements for insert to authenticated with check (created_by=auth.uid() and status='pending');
create policy movements_admin_update on public.movements for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy obligations_read on public.obligations for select to authenticated using (true);
create policy obligations_add on public.obligations for insert to authenticated with check (created_by=auth.uid() and status='pending');
create policy obligations_admin_update on public.obligations for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy budgets_read on public.budgets for select to authenticated using (true);
create policy budgets_admin on public.budgets for all to authenticated using (public.is_admin()) with check (public.is_admin());
create policy personal_own_read on public.personal_movements for select to authenticated using (owner_id=auth.uid() and public.is_admin());
create policy personal_own_insert on public.personal_movements for insert to authenticated with check (owner_id=auth.uid() and public.is_admin());
create policy personal_own_update on public.personal_movements for update to authenticated using (owner_id=auth.uid() and public.is_admin()) with check (owner_id=auth.uid() and public.is_admin());
create policy personal_own_delete on public.personal_movements for delete to authenticated using (owner_id=auth.uid() and public.is_admin());
-- Tras crear usuarios en Authentication > Users, insertar perfiles desde SQL Editor (service role):
-- insert into public.profiles(id,display_name,role) values ('UUID-DEL-DUENO','Bautista','admin'),('UUID-DEL-PAPA','Papá','member'),('UUID-DEL-HERMANO','Hermano','member');
-- Crear cuentas iniciales en SQL Editor o desde el panel de administrador.
-- Seguridad: deshabilitar registro público en Auth para mantener solo los 3 usuarios invitados.
